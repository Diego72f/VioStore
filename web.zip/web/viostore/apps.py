from django.apps import AppConfig


class ViostoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'viostore'
