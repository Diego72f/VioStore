from django.urls import path
from .views import inicio, contacto, loganpuff, vansknu, niketn, hoodiehockey, j4thunder, technocta, faripbandit, adi2000wht, perfil, caps, limpiezatillas, capwonka
from .views import hoodiesupreme, campuspink, suedexlplsr

urlpatterns = [
    path('inicio', inicio, name="inicio"),
    path('inicio/contacto', contacto, name="contacto"),
    path('inicio/loganpuff', loganpuff, name="loganpuff"),
    path('inicio/vansknu', vansknu, name="vansknu"),
    path('inicio/niketn', niketn, name="niketn"),
    path('inicio/hoodiehockey', hoodiehockey, name="hoodiehockey"),
    path('inicio/j4thunder', j4thunder, name="j4thunder"),
    path('inicio/technocta', technocta, name="technocta"),
    path('inicio/faripbandit', faripbandit, name="faripbandit"),
    path('inicio/adi2000wht', adi2000wht, name="adi2000wht"),
    path('inicio/perfil', perfil, name="perfil"),
    path('inicio/caps', caps, name="caps"),
    path('inicio/limpiezatillas', limpiezatillas, name="limpiezatillas"),
    path('inicio/capwonka', capwonka, name="capwonka"),
    path('inicio/hoodiesupreme', hoodiesupreme, name="hoodiesupreme"),
    path('inicio/campuspink', campuspink, name="campuspink"),
    path('inicio/suedexlplsr', suedexlplsr, name="suedexlplsr"),
]