from django.shortcuts import render

# Create your views here.
def inicio(request):
    return render(request, 'index.html')

def contacto(request):
    return render(request, 'contacto.html')

def loganpuff(request):
    return render(request, 'strayeloganpuff.html')

def vansknu(request):
    return render(request, 'vansknu.html')

def niketn(request):
    return render(request, 'niketn.html')

def hoodiehockey(request):
    return render(request, 'hoodiehockey.html')

def j4thunder(request):
    return render(request, 'j4thunder.html')

def technocta(request):
    return render(request, 'technocta.html')

def faripbandit(request):
    return render(request, 'faripbandit.html')

def adi2000wht(request):
    return render(request, 'adi2000wht.html')

def perfil(request):
    return render(request, 'perfil.html')

def caps(request):
    return render(request, 'caps.html')

def limpiezatillas(request):
    return render(request, 'limpiezatillas.html')

def capwonka(request):
    return render(request, 'capwonka.html')

def hoodiesupreme(request):
    return render(request, 'hoodiesupreme.html')

def campuspink(request):
    return render(request, 'campuspink.html')

def suedexlplsr(request):
    return render(request, 'suedexlplsr.html')